#include "Head.h"


void CSpriteA::Add(const std::wstring& strTexFileName /*= L""*/, int x /*= 0*/, int y /*= 0*/, int sx /*= 0*/, int sy /*= 0*/, int pivotx /*= 0*/, int pivoty /*= 0*/, float fTimeToShow /*= .1f*/)
{
	m_vecSprites.push_back(CSprite(strTexFileName, x, y, sx, sy, pivotx, pivoty));
	m_vecTimes.push_back(fTimeToShow);
}

void CSpriteA::Draw(D3DXVECTOR2 pos, float fTime, float fSize)
{
	size_t i = 0;
	for (; i < m_vecTimes.size(); i++)
	{
		if (fTime>m_vecTimes[i])
			fTime -= m_vecTimes[i];
		else
			break;

	}
	if (i == m_vecTimes.size())
		i = m_vecTimes.size() - 1;

	m_vecSprites[i].Draw(pos, fSize);
}

float CSpriteA::GetLength() const
{
	float fTime = 0.0f;
	for (size_t index = 0; index < m_vecTimes.size(); index++)
		fTime += m_vecTimes[index];
	return fTime;
}

CSpriteA::CSpriteA()
{

}

CSpriteA::~CSpriteA()
{

}
