#pragma once

#include "Head.h"

class CTexture
{
	PCTexture m_pTexture;
	VertPosTc m_v[4];//vertexes of sprite

	CRect m_rect;
	CPoint m_pivot;
};