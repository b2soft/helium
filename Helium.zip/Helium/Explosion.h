#pragma once

#include "Head.h"

class CExplosion
{
	float		m_fPlayTime;
	CSpriteA	m_anim;
	D3DXVECTOR2 m_pos;

public:
	CExplosion();
	CExplosion(D3DXVECTOR2 pos);
	~CExplosion();

	void Update(float fDeltaTime);
	void Draw();
	bool IsFinished() const;

};