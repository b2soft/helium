#include "Head.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR lpCmdLine, int nShowCmd)
{
	CSystem::Initialize(hInstance);
	return 0;
}